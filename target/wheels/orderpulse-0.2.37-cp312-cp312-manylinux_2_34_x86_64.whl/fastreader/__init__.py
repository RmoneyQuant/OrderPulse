from __future__ import annotations

from typing import Iterator, Optional

from .fastreader import MessageCacheReader, OrderbookBuilder, StreamingBinaryLoader, FeedPathBuilder
from . import fastreader as _fastreader


class BinaryDataLoader:
    """Compatibility wrapper around the new MessageCacheReader/StreamingBinaryLoader API."""

    def __init__(self, path: str, token: Optional[int] = None) -> None:
        if token is not None:
            raise ValueError(
                "token filtering is not supported in the current API. "
                "Use MessageCacheReader and filter messages in Python."
            )

        self._cache = MessageCacheReader()
        self._cache.load_to_cache(path)

        self._stream = StreamingBinaryLoader()
        self._stream.open_stream(path)

    def total_messages(self) -> int:
        return int(self._cache.get_cache_summary()["total_messages"])

    def total_orders(self) -> int:
        return int(self._cache.get_cache_summary()["total_orders"])

    def total_trades(self) -> int:
        return int(self._cache.get_cache_summary()["total_trades"])

    def reset_cursor(self) -> None:
        self._stream.reset_cursor()

    def summary(self) -> str:
        s = self._cache.get_cache_summary()
        return (
            f"file_path={s['file_path']}\n"
            f"total_messages={s['total_messages']}\n"
            f"total_orders={s['total_orders']}\n"
            f"total_trades={s['total_trades']}\n"
            f"memory_usage_bytes={s['memory_usage_bytes']}"
        )

    def get_all_messages(self, limit: Optional[int] = None) -> list[str]:
        return self._cache.get_all_messages(limit)

    def get_order_messages(self, limit: Optional[int] = None) -> list[str]:
        msgs = [m for m in self._cache.get_all_messages(None) if m.startswith("Order Message:")]
        if limit is None:
            return msgs
        return msgs[:limit]

    def get_trade_messages(self, limit: Optional[int] = None) -> list[str]:
        msgs = [m for m in self._cache.get_all_messages(None) if m.startswith("Trade Message:")]
        if limit is None:
            return msgs
        return msgs[:limit]

    def get_next_message(self) -> str:
        return self._stream.get_next_message()


class BinaryLoader(Iterator[str]):
    def __init__(self, reader: BinaryDataLoader) -> None:
        self._reader = reader
        self._ended = False

    def __iter__(self) -> BinaryLoader:
        return self

    def __next__(self) -> str:
        if self._ended:
            raise StopIteration

        message = self._reader.get_next_message()
        if message == "END":
            self._ended = True
            raise StopIteration
        return message


ReadMsgFromBinary = BinaryDataLoader


__doc__ = _fastreader.__doc__

# Keep new and compatibility symbols visible from the package root.
__all__ = [
    "MessageCacheReader",
    "StreamingBinaryLoader",
    "OrderbookBuilder",
    "FeedPathBuilder",
    "BinaryDataLoader",
    "ReadMsgFromBinary",
    "BinaryLoader",
]
